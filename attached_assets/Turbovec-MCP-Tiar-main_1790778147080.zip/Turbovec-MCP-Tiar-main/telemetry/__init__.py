"""Retrieval telemetry."""
